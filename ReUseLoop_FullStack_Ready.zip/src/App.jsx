import React, { useEffect, useMemo, useState } from "react";
import {
  Search, Plus, Heart, User, LogOut, Menu, X, SlidersHorizontal,
  BookOpen, Bike, Calculator, Laptop, LampDesk, Package, ArrowRight,
  MapPin, ShieldCheck, MessageCircle, Flag, Check, Clock3, XCircle,
  LayoutDashboard, ClipboardList, Trash2, Camera, ChevronLeft, Send,
  CircleAlert, CheckCircle2
} from "lucide-react";
import { Link, Route, Routes, useNavigate, useParams, useLocation } from "react-router-dom";
import { supabase, supabaseConfigured } from "./supabase";

const CATEGORIES = [
  "Books & Notes", "Electronics", "Calculators", "Cycles",
  "Hostel Essentials", "Lab Supplies", "Clothing", "Furniture", "Other"
];
const TYPES = ["sale", "rent", "donation", "exchange"];
const CONDITIONS = ["new", "like_new", "good", "fair", "poor"];

const iconFor = (category) => {
  const map = {
    "Books & Notes": BookOpen,
    Electronics: Laptop,
    Calculators: Calculator,
    Cycles: Bike,
    "Hostel Essentials": LampDesk
  };
  return map[category] || Package;
};

const money = (v) => v == null ? "Free / Offer" : `₹${Number(v).toLocaleString("en-IN")}`;
const pretty = (v) => (v || "").replaceAll("_", " ").replace(/\b\w/g, x => x.toUpperCase());

function Notice({ children, type = "info" }) {
  return <div className={`notice ${type}`}>{children}</div>;
}

function Empty({ title, text, action }) {
  return (
    <div className="empty">
      <Package size={42} />
      <h3>{title}</h3>
      <p>{text}</p>
      {action}
    </div>
  );
}

function Layout({ session, profile, onSignedOut, children }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const logout = async () => {
    if (supabase) await supabase.auth.signOut();
    onSignedOut();
    navigate("/");
  };

  return (
    <div className="app">
      <header className="topbar">
        <Link className="brand" to="/" onClick={() => setOpen(false)}>
          <span className="brand-icon">↻</span>
          <span><b>ReUseLoop</b><small>Campus Reuse Platform</small></span>
        </Link>
        <button className="mobile-menu" onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button>
        <nav className={open ? "nav open" : "nav"}>
          <Link to="/" onClick={() => setOpen(false)}>Browse</Link>
          {session && <Link to="/sell" onClick={() => setOpen(false)}>Sell / Give</Link>}
          {session && <Link to="/dashboard" onClick={() => setOpen(false)}>Dashboard</Link>}
          {profile?.role === "admin" && <Link to="/admin" onClick={() => setOpen(false)}>Admin</Link>}
          {session ? (
            <button className="nav-user" onClick={logout}><LogOut size={17}/> Sign out</button>
          ) : (
            <Link className="login-btn" to="/auth" onClick={() => setOpen(false)}><User size={17}/> Login</Link>
          )}
        </nav>
      </header>
      {children}
      <footer className="footer">
        <div><b>ReUseLoop</b><p>Buy less. Reuse more. Save smarter.</p></div>
        <div className="footer-links"><span>Campus-first</span><span>Privacy-aware</span><span>Offline handover</span></div>
      </footer>
    </div>
  );
}

function Home({ session }) {
  const [items, setItems] = useState([]);
  const [campuses, setCampuses] = useState([]);
  const [filters, setFilters] = useState({ q:"", category:"", type:"", campus:"", max:"" });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!supabase) { setLoading(false); return; }
    setLoading(true);
    let q = supabase.from("listings")
      .select("*, campuses(name,city), profiles:owner_id(display_name)")
      .eq("availability_status", "available")
      .order("created_at", { ascending:false });

    if (filters.category) q = q.eq("category", filters.category);
    if (filters.type) q = q.eq("listing_type", filters.type);
    if (filters.campus) q = q.eq("campus_id", filters.campus);
    if (filters.max) q = q.lte("price", Number(filters.max));
    if (filters.q) q = q.or(`title.ilike.%${filters.q}%,description.ilike.%${filters.q}%`);

    const [a,b] = await Promise.all([
      q,
      supabase.from("campuses").select("*").eq("active",true).order("name")
    ]);
    if (!a.error) setItems(a.data || []);
    setCampuses(b.data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [filters.category, filters.type, filters.campus, filters.max]);

  const submit = (e) => { e.preventDefault(); load(); };

  return (
    <>
      {!supabaseConfigured && <div className="setup-banner">Connect Supabase using <code>.env</code> and run <code>supabase/schema.sql</code> to enable the real backend.</div>}
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">CAMPUS MARKETPLACE</span>
          <h1>Useful things deserve <em>another life.</em></h1>
          <p>Buy, sell, rent, donate or exchange student-owned items through one organized campus platform.</p>
          <form className="searchbar" onSubmit={submit}>
            <Search size={21}/>
            <input value={filters.q} onChange={e=>setFilters({...filters,q:e.target.value})} placeholder="Search textbooks, cycles, calculators..." />
            <button>Search</button>
          </form>
          <div className="chips">
            {["Books & Notes","Electronics","Calculators","Cycles"].map(c =>
              <button key={c} className={filters.category===c ? "chip selected":"chip"} onClick={()=>setFilters({...filters,category:filters.category===c?"":c})}>{c}</button>
            )}
          </div>
        </div>
        <div className="hero-panel">
          <div className="hero-panel-head"><ShieldCheck size={22}/><b>Campus-first reuse</b></div>
          <h3>Four ways to reuse</h3>
          <div className="modes"><span>↗ Sell</span><span>↺ Rent</span><span>♥ Donate</span><span>⇄ Exchange</span></div>
          <p>Discovery happens online; users coordinate the physical handover at an agreed campus location.</p>
        </div>
      </section>

      <main className="container">
        <div className="section-head">
          <div><span className="eyebrow">DISCOVER</span><h2>Available on campus</h2></div>
          <button className="outline-btn" onClick={()=>setFilters({q:"",category:"",type:"",campus:"",max:""})}><SlidersHorizontal size={16}/> Reset</button>
        </div>
        <div className="filters">
          <select value={filters.type} onChange={e=>setFilters({...filters,type:e.target.value})}><option value="">All types</option>{TYPES.map(x=><option key={x}>{x}</option>)}</select>
          <select value={filters.campus} onChange={e=>setFilters({...filters,campus:e.target.value})}><option value="">All campuses</option>{campuses.map(c=><option key={c.campus_id} value={c.campus_id}>{c.name}</option>)}</select>
          <input type="number" min="0" value={filters.max} onChange={e=>setFilters({...filters,max:e.target.value})} placeholder="Max ₹"/>
        </div>
        {!supabaseConfigured ? (
          <Empty title="Backend not connected" text="The complete UI and backend schema are included. Add your Supabase credentials to start using real accounts and listings."/>
        ) : loading ? <div className="loading">Loading listings…</div> :
          items.length ? <div className="listing-grid">{items.map(i=><ListingCard item={i} key={i.listing_id}/>)}</div> :
          <Empty title="No matching listings" text="Try a different keyword, category or filter."/>
        }
      </main>
    </>
  );
}

function ListingCard({ item }) {
  const Icon = iconFor(item.category);
  return (
    <Link to={`/listing/${item.listing_id}`} className="listing-card">
      <div className="card-image">
        {item.cover_image_url ? <img src={item.cover_image_url} alt={item.title}/> : <Icon size={48}/>}
        <span className="badge">{item.listing_type}</span>
      </div>
      <div className="card-body">
        <div className="card-meta"><span>{pretty(item.condition)}</span><b>{money(item.price)}</b></div>
        <h3>{item.title}</h3>
        <p className="muted"><MapPin size={14}/> {item.campuses?.name || "Campus"}</p>
        <div className="card-foot"><span>{item.profiles?.display_name || "Student"}</span><span className="available">● Available</span></div>
      </div>
    </Link>
  );
}

function Auth({ onAuth }) {
  const [mode,setMode]=useState("login");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [name,setName]=useState("");
  const [campus,setCampus]=useState("");
  const [campuses,setCampuses]=useState([]);
  const [message,setMessage]=useState("");
  const [error,setError]=useState("");
  const [busy,setBusy]=useState(false);

  useEffect(()=>{ if(supabase) supabase.from("campuses").select("*").eq("active",true).order("name").then(({data})=>setCampuses(data||[])); },[]);

  const submit = async e => {
    e.preventDefault(); setBusy(true); setError(""); setMessage("");
    if (!supabase) { setError("Supabase is not configured. Copy .env.example to .env and add your project credentials."); setBusy(false); return; }
    if (mode==="login") {
      const {data,error}=await supabase.auth.signInWithPassword({email,password});
      if(error) setError(error.message); else onAuth(data.session);
    } else {
      const {data,error}=await supabase.auth.signUp({email,password,options:{data:{display_name:name,campus_id:campus}}});
      if(error) setError(error.message);
      else if(data.session) onAuth(data.session);
      else setMessage("Account created. Check your email if email confirmation is enabled, then sign in.");
    }
    setBusy(false);
  };

  return (
    <main className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">↻</div>
        <span className="eyebrow">{mode==="login"?"WELCOME BACK":"JOIN THE CAMPUS"}</span>
        <h1>{mode==="login"?"Sign in to ReUseLoop":"Create your account"}</h1>
        <p className="muted">Use your campus account and keep reuse within a trusted community.</p>
        {error && <Notice type="error">{error}</Notice>}
        {message && <Notice type="success">{message}</Notice>}
        <form onSubmit={submit} className="form">
          {mode==="signup" && <>
            <label>Display name<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"/></label>
            <label>Campus<select required value={campus} onChange={e=>setCampus(e.target.value)}><option value="">Select campus</option>{campuses.map(c=><option key={c.campus_id} value={c.campus_id}>{c.name}</option>)}</select></label>
          </>}
          <label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="student@example.com"/></label>
          <label>Password<input required minLength="6" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Minimum 6 characters"/></label>
          <button className="primary-btn" disabled={busy}>{busy?"Please wait…":mode==="login"?"Sign in":"Create account"}</button>
        </form>
        <button className="text-btn" onClick={()=>{setMode(mode==="login"?"signup":"login");setError("");setMessage("")}}>
          {mode==="login"?"New here? Create an account":"Already have an account? Sign in"}
        </button>
      </div>
    </main>
  );
}

function ListingDetail({ session, profile }) {
  const { id }=useParams();
  const navigate=useNavigate();
  const [item,setItem]=useState(null);
  const [request,setRequest]=useState("");
  const [fav,setFav]=useState(false);
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");
  const [error,setError]=useState("");
  const [report,setReport]=useState("");
  const [showReport,setShowReport]=useState(false);

  const load=async()=>{
    if(!supabase) return;
    const {data,error}=await supabase.from("listings").select("*, campuses(name,city), profiles:owner_id(display_name,role)").eq("listing_id",id).single();
    if(!error) setItem(data);
    if(session) {
      const {data:f}=await supabase.from("favorites").select("*").eq("user_id",session.user.id).eq("listing_id",id).maybeSingle();
      setFav(Boolean(f));
    }
  };
  useEffect(()=>{load()},[id,session?.user?.id]);

  const toggleFav=async()=>{
    if(!session){navigate("/auth");return;}
    if(fav){await supabase.from("favorites").delete().eq("user_id",session.user.id).eq("listing_id",id);setFav(false);}
    else {await supabase.from("favorites").insert({user_id:session.user.id,listing_id:id});setFav(true);}
  };

  const sendRequest=async()=>{
    if(!session){navigate("/auth");return;}
    if(!request.trim()){setError("Write a short message.");return;}
    setBusy(true);setError("");setMessage("");
    const {error:e}=await supabase.from("transaction_requests").insert({
      listing_id:id, requester_id:session.user.id, message:request.trim(), request_status:"pending"
    });
    if(e) setError(e.message); else {setMessage("Request sent to the owner.");setRequest("");}
    setBusy(false);
  };

  const submitReport=async()=>{
    if(!session){navigate("/auth");return;}
    if(!report.trim()){setError("Add a reason.");return;}
    const {error:e}=await supabase.from("reports").insert({reporter_id:session.user.id,listing_id:id,reason:"User report",details:report.trim()});
    if(e) setError(e.message); else {setMessage("Report submitted for admin review.");setShowReport(false);setReport("");}
  };

  if(!item) return <main className="container page"><div className="loading">Loading item…</div></main>;

  const Icon=iconFor(item.category);
  const own=profile?.user_id===item.owner_id;

  return (
    <main className="container page">
      <button className="back-btn" onClick={()=>navigate(-1)}><ChevronLeft size={18}/> Back</button>
      <div className="detail">
        <div className="detail-image">{item.cover_image_url?<img src={item.cover_image_url} alt={item.title}/>:<Icon size={90}/>}</div>
        <div className="detail-copy">
          <div className="detail-top"><span className="badge">{item.listing_type}</span><button className={fav?"heart active":"heart"} onClick={toggleFav}><Heart fill={fav?"currentColor":"none"}/></button></div>
          <span className="eyebrow">{item.category}</span>
          <h1>{item.title}</h1>
          <div className="price">{money(item.price)}</div>
          <p className="muted"><MapPin size={16}/> {item.campuses?.name}, {item.campuses?.city}</p>
          <div className="condition">{pretty(item.condition)} condition</div>
          <p className="description">{item.description}</p>
          <div className="owner"><div className="avatar">{(item.profiles?.display_name||"S")[0]}</div><div><b>{item.profiles?.display_name||"Student"}</b><small>Campus member</small></div></div>
          {message&&<Notice type="success"><CheckCircle2 size={17}/> {message}</Notice>}
          {error&&<Notice type="error"><CircleAlert size={17}/> {error}</Notice>}
          {!own && session && item.availability_status==="available" && (
            <div className="request-box">
              <label>Request this item<textarea value={request} onChange={e=>setRequest(e.target.value)} placeholder="Hi, I am interested. When can we meet for pickup?"/></label>
              <button className="primary-btn" disabled={busy} onClick={sendRequest}><Send size={17}/> {busy?"Sending…":"Send request"}</button>
            </div>
          )}
          {!session && <Link className="primary-btn wide" to="/auth">Sign in to request</Link>}
          <div className="detail-actions">
            <button className="outline-btn" onClick={()=>setShowReport(!showReport)}><Flag size={16}/> Report</button>
            {own && <Link className="outline-btn" to="/dashboard"><ClipboardList size={16}/> Manage listing</Link>}
          </div>
          {showReport&&<div className="report-box"><textarea value={report} onChange={e=>setReport(e.target.value)} placeholder="Tell the admin what looks wrong…"/><button className="danger-btn" onClick={submitReport}>Submit report</button></div>}
        </div>
      </div>
    </main>
  );
}

function Sell({ session, profile }) {
  const navigate=useNavigate();
  const [campuses,setCampuses]=useState([]);
  const [form,setForm]=useState({title:"",description:"",category:"Books & Notes",listing_type:"sale",condition:"good",price:"",campus_id:profile?.campus_id||"",cover_image_url:""});
  const [file,setFile]=useState(null);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");

  useEffect(()=>{if(supabase)supabase.from("campuses").select("*").eq("active",true).order("name").then(({data})=>setCampuses(data||[]));},[]);

  const submit=async e=>{
    e.preventDefault(); setBusy(true); setError("");
    if(!supabase){setError("Supabase is not configured.");setBusy(false);return;}
    let url="";
    if(file){
      const ext=file.name.split(".").pop().toLowerCase();
      if(!["jpg","jpeg","png","webp"].includes(ext)){setError("Use JPG, PNG or WEBP.");setBusy(false);return;}
      if(file.size>5*1024*1024){setError("Image must be 5 MB or smaller.");setBusy(false);return;}
      const path=`${session.user.id}/${crypto.randomUUID()}.${ext}`;
      const up=await supabase.storage.from("listing-images").upload(path,file,{contentType:file.type,upsert:false});
      if(up.error){setError(up.error.message);setBusy(false);return;}
      url=supabase.storage.from("listing-images").getPublicUrl(path).data.publicUrl;
    }
    const payload={...form,owner_id:session.user.id,price:form.price===""?null:Number(form.price),cover_image_url:url||null,availability_status:"available"};
    const {data,error:e}=await supabase.from("listings").insert(payload).select().single();
    if(e) setError(e.message); else navigate(`/listing/${data.listing_id}`);
    setBusy(false);
  };

  return <main className="container page narrow">
    <span className="eyebrow">LISTING MANAGEMENT</span><h1>Create a listing</h1><p className="muted">Sell, rent, donate or exchange a useful item with another student.</p>
    {error&&<Notice type="error">{error}</Notice>}
    <form className="form card-form" onSubmit={submit}>
      <label>Title<input required maxLength="120" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Engineering Mathematics book"/></label>
      <div className="two">
        <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{CATEGORIES.map(x=><option key={x}>{x}</option>)}</select></label>
        <label>Transaction type<select value={form.listing_type} onChange={e=>setForm({...form,listing_type:e.target.value})}>{TYPES.map(x=><option key={x}>{x}</option>)}</select></label>
      </div>
      <div className="two">
        <label>Condition<select value={form.condition} onChange={e=>setForm({...form,condition:e.target.value})}>{CONDITIONS.map(x=><option key={x}>{x}</option>)}</select></label>
        <label>Price (₹)<input type="number" min="0" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="Leave empty for donation / offer"/></label>
      </div>
      <label>Campus<select required value={form.campus_id} onChange={e=>setForm({...form,campus_id:e.target.value})}><option value="">Select campus</option>{campuses.map(c=><option key={c.campus_id} value={c.campus_id}>{c.name}</option>)}</select></label>
      <label>Description<textarea required minLength="10" maxLength="3000" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe condition, what is included and pickup details."/></label>
      <label className="upload"><Camera size={22}/><span>{file?file.name:"Add one cover photo (JPG/PNG/WEBP, max 5 MB)"}</span><input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setFile(e.target.files?.[0]||null)}/></label>
      <button className="primary-btn" disabled={busy}>{busy?"Publishing…":"Publish listing"}</button>
    </form>
  </main>;
}

function Dashboard({ session, profile }) {
  const [mine,setMine]=useState([]);
  const [requests,setRequests]=useState([]);
  const [favorites,setFavorites]=useState([]);
  const [tab,setTab]=useState("listings");
  const [msg,setMsg]=useState("");

  const load=async()=>{
    if(!supabase)return;
    const [a,b,c]=await Promise.all([
      supabase.from("listings").select("*, campuses(name)").eq("owner_id",session.user.id).order("created_at",{ascending:false}),
      supabase.from("transaction_requests").select("*, listings(title,owner_id,price), profiles:requester_id(display_name)").or(`requester_id.eq.${session.user.id}`),
      supabase.from("favorites").select("*, listings(*, campuses(name))").eq("user_id",session.user.id)
    ]);
    setMine(a.data||[]);setRequests(b.data||[]);setFavorites(c.data||[]);
  };
  useEffect(()=>{load()},[session.user.id]);

  const updateRequest=async(r,status)=>{
    const {error}=await supabase.from("transaction_requests").update({request_status:status,responded_at:new Date().toISOString()}).eq("request_id",r.request_id);
    if(error)setMsg(error.message);else{setMsg(`Request ${status}.`);load();}
  };
  const closeListing=async(id)=>{
    await supabase.from("listings").update({availability_status:"closed"}).eq("listing_id",id);
    load();
  };

  const incoming = requests.filter(r=>r.listings?.owner_id===session.user.id);
  const outgoing = requests.filter(r=>r.requester_id===session.user.id);

  return <main className="container page">
    <div className="dashboard-head"><div><span className="eyebrow">YOUR SPACE</span><h1>Dashboard</h1><p className="muted">Manage listings, requests and saved items.</p></div><Link className="primary-btn" to="/sell"><Plus size={17}/> New listing</Link></div>
    {msg&&<Notice type="success">{msg}</Notice>}
    <div className="stats"><div><b>{mine.length}</b><span>Listings</span></div><div><b>{incoming.filter(r=>r.request_status==="pending").length}</b><span>Pending requests</span></div><div><b>{favorites.length}</b><span>Favorites</span></div></div>
    <div className="tabs"><button className={tab==="listings"?"active":""} onClick={()=>setTab("listings")}>My listings</button><button className={tab==="requests"?"active":""} onClick={()=>setTab("requests")}>Requests</button><button className={tab==="favorites"?"active":""} onClick={()=>setTab("favorites")}>Favorites</button></div>
    {tab==="listings"&&<div className="dash-list">{mine.map(i=><div className="dash-item" key={i.listing_id}><div><b>{i.title}</b><small>{i.listing_type} · {pretty(i.availability_status)} · {money(i.price)}</small></div><div className="row-actions"><Link className="outline-btn small" to={`/listing/${i.listing_id}`}>View</Link>{i.availability_status!=="closed"&&<button className="danger-btn small" onClick={()=>closeListing(i.listing_id)}>Close</button>}</div></div>)}{!mine.length&&<Empty title="No listings yet" text="Create your first listing and help another student reuse it."/>}</div>}
    {tab==="requests"&&<div className="request-columns"><div><h3>Requests on my listings</h3>{incoming.map(r=><RequestRow key={r.request_id} r={r} owner onAction={updateRequest}/>)}</div><div><h3>My requests</h3>{outgoing.map(r=><RequestRow key={r.request_id} r={r} onAction={updateRequest}/>)}</div></div>}
    {tab==="favorites"&&<div className="listing-grid">{favorites.map(f=>f.listings&&<ListingCard item={f.listings} key={f.listing_id}/>)}{!favorites.length&&<Empty title="No favorites" text="Tap the heart on a listing to save it here."/>}</div>}
  </main>;
}

function RequestRow({r,owner,onAction}) {
  return <div className="request-row"><div className="request-icon">{r.request_status==="accepted"?<Check/>:r.request_status==="rejected"?<XCircle/>:<Clock3/>}</div><div className="request-main"><b>{r.listings?.title||"Listing"}</b><p>{r.message}</p><small>{owner?`From ${r.profiles?.display_name||"student"}`:"Status"} · {pretty(r.request_status)}</small></div>{owner&&r.request_status==="pending"&&<div className="row-actions"><button className="primary-btn small" onClick={()=>onAction(r,"accepted")}>Accept</button><button className="danger-btn small" onClick={()=>onAction(r,"rejected")}>Reject</button></div>}</div>;
}

function Admin({ profile }) {
  const [reports,setReports]=useState([]);
  const [message,setMessage]=useState("");
  const load=async()=>{const {data}=await supabase.from("reports").select("*, listings(title), profiles:reporter_id(display_name)").order("created_at",{ascending:false});setReports(data||[]);}
  useEffect(()=>{load()},[]);
  const moderate=async(r,status)=>{
    await supabase.from("reports").update({status}).eq("report_id",r.report_id);
    await supabase.from("admin_actions").insert({admin_id:profile.user_id,report_id:r.report_id,target_listing_id:r.listing_id,action_type:`report_${status}`,notes:"Admin moderation action"});
    setMessage(`Report marked ${status}.`);load();
  };
  return <main className="container page">
    <span className="eyebrow">MODERATION</span><h1>Admin panel</h1><p className="muted">Review reports and keep the marketplace safe.</p>
    {message&&<Notice type="success">{message}</Notice>}
    <div className="admin-list">{reports.map(r=><div className="admin-report" key={r.report_id}><div><div className="status-line"><span className={`status ${r.status}`}>{r.status}</span><small>{new Date(r.created_at).toLocaleString()}</small></div><h3>{r.listings?.title||"Reported user/content"}</h3><p>{r.reason}: {r.details}</p><small>Reported by {r.profiles?.display_name||"student"}</small></div><div className="row-actions">{r.status==="open"&&<><button className="primary-btn small" onClick={()=>moderate(r,"resolved")}>Resolve</button><button className="danger-btn small" onClick={()=>moderate(r,"dismissed")}>Dismiss</button></>}</div></div>)}</div>
    {!reports.length&&<Empty title="No reports" text="The moderation queue is clear."/>}
  </main>;
}

function App() {
  const [session,setSession]=useState(null);
  const [profile,setProfile]=useState(null);
  const [ready,setReady]=useState(!supabaseConfigured);
  const navigate=useNavigate();

  const loadProfile=async(s)=>{
    if(!s||!supabase){setProfile(null);return;}
    const {data}=await supabase.from("profiles").select("*").eq("user_id",s.user.id).maybeSingle();
    setProfile(data||null);
  };

  useEffect(()=>{
    if(!supabase){setReady(true);return;}
    supabase.auth.getSession().then(({data})=>{setSession(data.session);loadProfile(data.session);setReady(true);});
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>{setSession(s);loadProfile(s);});
    return ()=>subscription.unsubscribe();
  },[]);

  if(!ready) return <div className="boot">Loading ReUseLoop…</div>;

  const authHandler=(s)=>{setSession(s);loadProfile(s);navigate("/");};

  return <Layout session={session} profile={profile} onSignedOut={()=>{setSession(null);setProfile(null);}}>
    <Routes>
      <Route path="/" element={<Home session={session}/>}/>
      <Route path="/auth" element={session?<Home session={session}/>:<Auth onAuth={authHandler}/>}/>
      <Route path="/listing/:id" element={<ListingDetail session={session} profile={profile}/>}/>
      <Route path="/sell" element={session?<Sell session={session} profile={profile}/>:<Auth onAuth={authHandler}/>}/>
      <Route path="/dashboard" element={session?<Dashboard session={session} profile={profile}/>:<Auth onAuth={authHandler}/>}/>
      <Route path="/admin" element={profile?.role==="admin"?<Admin profile={profile}/>:<Home session={session}/>}/>
      <Route path="*" element={<Home session={session}/>}/>
    </Routes>
  </Layout>;
}

export default App;
