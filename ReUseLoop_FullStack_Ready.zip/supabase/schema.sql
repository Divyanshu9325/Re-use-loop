-- ReUseLoop database
-- Run this whole file in Supabase SQL Editor.
-- It creates the relational model described in the project presentation:
-- campuses, profiles, listings, transaction_requests, messages, favorites,
-- reports and admin_actions, with RLS and storage policies.

create extension if not exists pgcrypto;

do $$ begin
  create type public.user_role as enum ('student','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.verification_status as enum ('pending','verified','rejected');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.listing_type as enum ('sale','rent','donation','exchange');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.item_condition as enum ('new','like_new','good','fair','poor');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.availability_status as enum ('available','reserved','paused','closed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.request_status as enum ('pending','accepted','rejected','cancelled','completed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.report_status as enum ('open','resolved','dismissed');
exception when duplicate_object then null; end $$;

create table if not exists public.campuses (
  campus_id uuid primary key default gen_random_uuid(),
  name text not null unique,
  city text not null,
  allowed_email_domain text,
  verification_method text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  campus_id uuid references public.campuses(campus_id),
  display_name text not null,
  role public.user_role not null default 'student',
  verification_status public.verification_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  listing_id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(user_id) on delete restrict,
  campus_id uuid not null references public.campuses(campus_id) on delete restrict,
  title text not null check (char_length(title) between 3 and 120),
  description text not null check (char_length(description) between 10 and 3000),
  category text not null,
  listing_type public.listing_type not null,
  condition public.item_condition not null,
  price numeric(12,2) check (price is null or price >= 0),
  currency text not null default 'INR',
  availability_status public.availability_status not null default 'available',
  cover_image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listing_images (
  image_id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(listing_id) on delete cascade,
  storage_path text not null,
  alt_text text,
  display_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.transaction_requests (
  request_id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(listing_id) on delete cascade,
  requester_id uuid not null references public.profiles(user_id) on delete restrict,
  message text not null check (char_length(message) between 1 and 2000),
  request_status public.request_status not null default 'pending',
  created_at timestamptz not null default now(),
  responded_at timestamptz
);

create table if not exists public.transactions (
  transaction_id uuid primary key default gen_random_uuid(),
  request_id uuid unique references public.transaction_requests(request_id) on delete restrict,
  listing_id uuid not null references public.listings(listing_id) on delete restrict,
  buyer_or_requester_id uuid not null references public.profiles(user_id) on delete restrict,
  owner_id uuid not null references public.profiles(user_id) on delete restrict,
  transaction_type public.listing_type not null,
  status text not null default 'accepted' check (status in ('accepted','pickup_planned','completed','cancelled')),
  agreed_price numeric(12,2) check (agreed_price is null or agreed_price >= 0),
  start_date timestamptz,
  due_date timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  message_id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null references public.transactions(transaction_id) on delete cascade,
  sender_id uuid not null references public.profiles(user_id) on delete restrict,
  body text not null check (char_length(body) between 1 and 4000),
  sent_at timestamptz not null default now(),
  read_at timestamptz
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(user_id) on delete cascade,
  listing_id uuid not null references public.listings(listing_id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, listing_id)
);

create table if not exists public.reports (
  report_id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(user_id) on delete restrict,
  listing_id uuid references public.listings(listing_id) on delete set null,
  reported_user_id uuid references public.profiles(user_id) on delete set null,
  reason text not null,
  details text,
  status public.report_status not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.admin_actions (
  action_id uuid primary key default gen_random_uuid(),
  admin_id uuid not null references public.profiles(user_id) on delete restrict,
  report_id uuid references public.reports(report_id) on delete set null,
  target_listing_id uuid references public.listings(listing_id) on delete set null,
  action_type text not null,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_campus on public.profiles(campus_id);
create index if not exists idx_listings_campus on public.listings(campus_id);
create index if not exists idx_listings_owner on public.listings(owner_id);
create index if not exists idx_listings_status on public.listings(availability_status);
create index if not exists idx_listings_type on public.listings(listing_type);
create index if not exists idx_requests_listing on public.transaction_requests(listing_id);
create index if not exists idx_requests_requester on public.transaction_requests(requester_id);
create index if not exists idx_reports_status on public.reports(status);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists listings_updated_at on public.listings;
create trigger listings_updated_at before update on public.listings
for each row execute procedure public.set_updated_at();

-- Create profile automatically after signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles(user_id, display_name, campus_id)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)),
    nullif(new.raw_user_meta_data->>'campus_id','')::uuid
  )
  on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helpers
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where user_id=auth.uid() and role='admin') $$;

-- RLS
alter table public.campuses enable row level security;
alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_images enable row level security;
alter table public.transaction_requests enable row level security;
alter table public.transactions enable row level security;
alter table public.messages enable row level security;
alter table public.favorites enable row level security;
alter table public.reports enable row level security;
alter table public.admin_actions enable row level security;

drop policy if exists campuses_read on public.campuses;
create policy campuses_read on public.campuses for select using (active = true or public.is_admin());

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select using (auth.uid() = user_id or public.is_admin());

drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists listings_public_read on public.listings;
create policy listings_public_read on public.listings for select using (
  availability_status <> 'closed' or owner_id = auth.uid() or public.is_admin()
);

drop policy if exists listings_insert_own on public.listings;
create policy listings_insert_own on public.listings for insert with check (owner_id = auth.uid());

drop policy if exists listings_update_own on public.listings;
create policy listings_update_own on public.listings for update using (owner_id = auth.uid() or public.is_admin())
with check (owner_id = auth.uid() or public.is_admin());

drop policy if exists listings_delete_own on public.listings;
create policy listings_delete_own on public.listings for delete using (owner_id = auth.uid() or public.is_admin());

drop policy if exists listing_images_read on public.listing_images;
create policy listing_images_read on public.listing_images for select using (true);

drop policy if exists listing_images_write on public.listing_images;
create policy listing_images_write on public.listing_images for all using (
  exists(select 1 from public.listings l where l.listing_id=listing_id and (l.owner_id=auth.uid() or public.is_admin()))
) with check (
  exists(select 1 from public.listings l where l.listing_id=listing_id and (l.owner_id=auth.uid() or public.is_admin()))
);

drop policy if exists requests_insert on public.transaction_requests;
create policy requests_insert on public.transaction_requests for insert with check (
  requester_id=auth.uid()
  and exists(select 1 from public.listings l where l.listing_id=listing_id and l.owner_id<>auth.uid() and l.availability_status='available')
);

drop policy if exists requests_read on public.transaction_requests;
create policy requests_read on public.transaction_requests for select using (
  requester_id=auth.uid()
  or exists(select 1 from public.listings l where l.listing_id=listing_id and l.owner_id=auth.uid())
  or public.is_admin()
);

drop policy if exists requests_update on public.transaction_requests;
create policy requests_update on public.transaction_requests for update using (
  requester_id=auth.uid()
  or exists(select 1 from public.listings l where l.listing_id=listing_id and l.owner_id=auth.uid())
  or public.is_admin()
) with check (
  requester_id=auth.uid()
  or exists(select 1 from public.listings l where l.listing_id=listing_id and l.owner_id=auth.uid())
  or public.is_admin()
);

drop policy if exists favorites_own on public.favorites;
create policy favorites_own on public.favorites for all using (user_id=auth.uid()) with check (user_id=auth.uid());

drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports for insert with check (reporter_id=auth.uid());

drop policy if exists reports_read on public.reports;
create policy reports_read on public.reports for select using (reporter_id=auth.uid() or public.is_admin());

drop policy if exists reports_update_admin on public.reports;
create policy reports_update_admin on public.reports for update using (public.is_admin()) with check (public.is_admin());

drop policy if exists transactions_read on public.transactions;
create policy transactions_read on public.transactions for select using (
  buyer_or_requester_id=auth.uid() or owner_id=auth.uid() or public.is_admin()
);

drop policy if exists messages_read on public.messages;
create policy messages_read on public.messages for select using (
  exists(select 1 from public.transactions t where t.transaction_id=messages.transaction_id and (t.buyer_or_requester_id=auth.uid() or t.owner_id=auth.uid()))
  or public.is_admin()
);

drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages for insert with check (
  sender_id=auth.uid()
  and exists(select 1 from public.transactions t where t.transaction_id=messages.transaction_id and (t.buyer_or_requester_id=auth.uid() or t.owner_id=auth.uid()))
);

drop policy if exists admin_actions_admin on public.admin_actions;
create policy admin_actions_admin on public.admin_actions for all using (public.is_admin()) with check (public.is_admin());

-- Storage bucket for listing photos.
insert into storage.buckets (id, name, public)
values ('listing-images','listing-images',true)
on conflict (id) do update set public=true;

drop policy if exists listing_images_public_read on storage.objects;
create policy listing_images_public_read on storage.objects for select using (bucket_id='listing-images');

drop policy if exists listing_images_user_upload on storage.objects;
create policy listing_images_user_upload on storage.objects for insert to authenticated
with check (
  bucket_id='listing-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists listing_images_user_delete on storage.objects;
create policy listing_images_user_delete on storage.objects for delete to authenticated
using (
  bucket_id='listing-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Starter campus. Add more campuses as required.
insert into public.campuses(name, city, allowed_email_domain, verification_method)
values ('SR Group of Institutions', 'Jhansi', null, 'manual')
on conflict (name) do nothing;

-- After creating your own account, promote it to admin manually:
-- update public.profiles set role='admin' where user_id='YOUR_AUTH_USER_UUID';
